from django.shortcuts import render
from .models import Product
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
import requests

def product_list(request):
    products = Product.objects.all()
    return render(request, 'store/product_list.html', {'products': products})

def about_view(request):
    return render(request, 'store/about.html')

@csrf_exempt
def send_order(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        name = data.get('name')
        phone = data.get('phone')
        cart = data.get('cart')

        # ساخت پیام
        message = f"📦 سفارش جدید:\n👤 نام: {name}\n📞 شماره: {phone}\n🛒 سفارش:\n"
        for item in cart:
            message += f"- {item['name']} (x{item['quantity']})\n"

        token = '8478100778:AAHrTnixvuFJAJtHywFeVnpZOSwpRtMo6rY'  # توکن ربات تلگرام
        chat_id = '109908767'  # آیدی عددی

        url = f'https://api.telegram.org/bot{token}/sendMessage'

        try:
            response = requests.post(url, data={
                'chat_id': chat_id,
                'text': message
            })
            return JsonResponse({'status': 'ok'})
        except:
            return JsonResponse({'status': 'error'})
    return JsonResponse({'status': 'invalid request'})
