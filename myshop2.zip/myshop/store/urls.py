
from django.urls import path
from . import views
from .views import send_order  # ✅ اضافه شد

urlpatterns = [
    path('', views.product_list, name='product_list'),
    path('about/', views.about_view, name='about'),         # مثلا صفحه اصلی
    path('send-order/', send_order, name='send_order'),  # ارسال سفارش
]


